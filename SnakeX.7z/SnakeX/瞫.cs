﻿// Decompiled with JetBrains decompiler
// Type: 瞫
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System;

internal delegate AppDomain 瞫();
