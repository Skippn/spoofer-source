﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("ecd03fcb-bd26-40f2-a5c7-2c38a93632a9")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyProduct("Snake X")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("Snake X")]
[assembly: AssemblyVersion("1.0.0.0")]
