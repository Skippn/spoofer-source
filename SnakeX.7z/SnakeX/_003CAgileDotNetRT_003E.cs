﻿// Decompiled with JetBrains decompiler
// Type: <AgileDotNetRT>
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;

[SecuritySafeCritical]
internal class \u003CAgileDotNetRT\u003E
{
  private static byte[] pRM\u003D;
  private static Hashtable sc = new Hashtable();
  private static bool inited;
  private static Assembly runtimeAssembly;

  [MethodImpl(MethodImplOptions.NoInlining)]
  static \u003CAgileDotNetRT\u003E() => \u003CAgileDotNetRT\u003E.pRM\u003D = new byte[112]
  {
    (byte) 63,
    (byte) 149,
    (byte) 2,
    (byte) 4,
    (byte) 89,
    (byte) 7,
    (byte) 204,
    (byte) 29,
    (byte) 54,
    (byte) 212,
    (byte) 163,
    (byte) 88,
    (byte) 172,
    (byte) 110,
    (byte) 202,
    (byte) 233,
    (byte) 185,
    (byte) 149,
    (byte) 76,
    (byte) 240,
    (byte) 142,
    (byte) 202,
    (byte) 52,
    (byte) 152,
    (byte) 33,
    (byte) 201,
    (byte) 82,
    (byte) 8,
    (byte) 163,
    (byte) 197,
    (byte) 218,
    (byte) 179,
    (byte) 25,
    (byte) 243,
    (byte) 200,
    (byte) 38,
    (byte) 101,
    (byte) 226,
    (byte) 129,
    (byte) 78,
    (byte) 74,
    (byte) 108,
    (byte) 141,
    (byte) 160,
    (byte) 91,
    (byte) 95,
    (byte) 201,
    (byte) 15,
    (byte) 50,
    (byte) 4,
    (byte) 135,
    (byte) 233,
    (byte) 3,
    (byte) 198,
    (byte) 11,
    (byte) 116,
    (byte) 96,
    (byte) 105,
    (byte) 225,
    (byte) 143,
    (byte) 180,
    (byte) 195,
    (byte) 121,
    (byte) 111,
    (byte) 248,
    (byte) 239,
    (byte) 63,
    (byte) 183,
    (byte) 165,
    (byte) 163,
    (byte) 132,
    (byte) 213,
    (byte) 19,
    (byte) 253,
    (byte) 166,
    (byte) 34,
    (byte) 60,
    (byte) 147,
    (byte) 60,
    (byte) 192,
    (byte) 254,
    (byte) 66,
    (byte) 212,
    (byte) 159,
    (byte) 61,
    (byte) 240,
    (byte) 175,
    (byte) 81,
    (byte) 231,
    (byte) 84,
    (byte) 197,
    (byte) 251,
    (byte) 1,
    (byte) 241,
    (byte) 153,
    (byte) 133,
    (byte) 242,
    (byte) 29,
    (byte) 166,
    (byte) 107,
    (byte) 32,
    (byte) 17,
    (byte) 105,
    (byte) 141,
    (byte) 127,
    (byte) 176,
    (byte) 213,
    (byte) 5,
    (byte) 32,
    (byte) 232,
    (byte) 56,
    (byte) 204
  };

  internal static string oRM\u003D([In] string obj0)
  {
    Hashtable sc;
    瞕.RgAAAA\u003D\u003D((object) (sc = \u003CAgileDotNetRT\u003E.sc));
    try
    {
      if (瞖.QAAAAA\u003D\u003D\u0025((object) \u003CAgileDotNetRT\u003E.sc, (object) obj0))
        return (string) 瞗.QQAAAA\u003D\u003D\u0025((object) \u003CAgileDotNetRT\u003E.sc, (object) obj0);
      StringBuilder stringBuilder1 = new StringBuilder();
      for (int index = 0; index < obj0.Length; ++index)
      {
        StringBuilder stringBuilder2 = 瞙.RAAAAA\u003D\u003D\u0025((object) stringBuilder1, 瞘.RQAAAA\u003D\u003D((int) obj0[index] ^ (int) \u003CAgileDotNetRT\u003E.pRM\u003D[index % \u003CAgileDotNetRT\u003E.pRM\u003D.Length]));
      }
      瞚.QgAAAA\u003D\u003D\u0025((object) \u003CAgileDotNetRT\u003E.sc, (object) obj0, (object) 瞉.DgAAAA\u003D\u003D\u0025((object) stringBuilder1));
      return 瞉.DgAAAA\u003D\u003D\u0025((object) stringBuilder1);
    }
    finally
    {
      瞕.RwAAAA\u003D\u003D((object) sc);
    }
  }

  [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
  [MethodImpl(MethodImplOptions.ForwardRef)]
  private static extern IntPtr LoadLibraryA([In] string obj0);

  [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
  [MethodImpl(MethodImplOptions.ForwardRef)]
  private static extern IntPtr GetProcAddress([In] IntPtr obj0, [In] string obj1);

  [DllImport("AgileDotNetRT.dll", CharSet = CharSet.Ansi)]
  [MethodImpl(MethodImplOptions.ForwardRef)]
  private static extern int _Initialize([In] IntPtr obj0);

  [DllImport("AgileDotNetRT64.dll", CharSet = CharSet.Ansi)]
  [MethodImpl(MethodImplOptions.ForwardRef)]
  private static extern int _Initialize64([In] IntPtr obj0);

  [DllImport("AgileDotNetRT.dll", CharSet = CharSet.Ansi)]
  [MethodImpl(MethodImplOptions.ForwardRef)]
  private static extern void _AtExit();

  [DllImport("AgileDotNetRT64.dll", EntryPoint = "_AtExit", CharSet = CharSet.Ansi)]
  [MethodImpl(MethodImplOptions.ForwardRef)]
  private static extern void _AtExit64();

  internal static IntPtr Load()
  {
    Type type;
    // ISSUE: type reference
    瞕.RgAAAA\u003D\u003D((object) (type = 瞊.MAAAAA\u003D\u003D(__typeref (\u003CAgileDotNetRT\u003E))));
    try
    {
      WindowsImpersonationContext impersonationContext;
      try
      {
        impersonationContext = WindowsIdentity.Impersonate(IntPtr.Zero);
        Assembly assembly = 瞛.MgAAAA\u003D\u003D();
        string name;
        string str1;
        if (瞜.bQAAAA\u003D\u003D() == 4)
        {
          name = "11cd9026-fb7a-470b-af5b-6967a19a559c";
          str1 = "AgileDotNetRT";
        }
        else
        {
          name = "67f71db0-b2b6-4606-a764-032223b4dce6";
          str1 = "AgileDotNetRT64";
        }
        BinaryReader binaryReader = new BinaryReader((Stream) new GZipStream(assembly.GetManifestResourceStream(name), CompressionMode.Decompress));
        byte[] numArray = 瞞.YQAAAA\u003D\u003D\u0025((object) binaryReader, 瞝.YgAAAA\u003D\u003D\u0025((object) binaryReader));
        string str2 = 瞠.LQAAAA\u003D\u003D("{0}{1}\\", (object) 瞟.bgAAAA\u003D\u003D(), (object) name);
        DirectoryInfo directoryInfo = 睸.HQAAAA\u003D\u003D(str2);
        string str3 = 瞡.LwAAAA\u003D\u003D(str2, str1, ".dll");
        if (!睷.HgAAAA\u003D\u003D(str3))
        {
          FileStream fileStream = 瞢.HwAAAA\u003D\u003D(str3);
          瞣.GQAAAA\u003D\u003D\u0025((object) fileStream, numArray, 0, numArray.Length);
          睺.GgAAAA\u003D\u003D\u0025((object) fileStream);
          FileSystemAccessRule systemAccessRule = new FileSystemAccessRule((IdentityReference) new SecurityIdentifier("S-1-1-0"), FileSystemRights.ReadAndExecute, AccessControlType.Allow);
          FileSecurity fileSecurity = 瞤.IAAAAA\u003D\u003D(str3);
          瞥.bwAAAA\u003D\u003D\u0025((object) fileSecurity, systemAccessRule);
          瞦.IQAAAA\u003D\u003D(str3, fileSecurity);
        }
        return \u003CAgileDotNetRT\u003E.LoadLibraryA(str3);
      }
      finally
      {
        impersonationContext.Undo();
      }
    }
    finally
    {
      瞕.RwAAAA\u003D\u003D((object) type);
    }
  }

  internal static int InitializeThroughDelegate([In] IntPtr obj0)
  {
    IntPtr procAddress = \u003CAgileDotNetRT\u003E.GetProcAddress(\u003CAgileDotNetRT\u003E.Load(), "_Initialize");
    // ISSUE: type reference
    return ((InitializeDelegate) 瞧.cAAAAA\u003D\u003D(procAddress, 瞊.MAAAAA\u003D\u003D(__typeref (InitializeDelegate))))(obj0);
  }

  internal static int InitializeThroughDelegate64([In] IntPtr obj0)
  {
    IntPtr procAddress = \u003CAgileDotNetRT\u003E.GetProcAddress(\u003CAgileDotNetRT\u003E.Load(), "_Initialize64");
    // ISSUE: type reference
    return ((InitializeDelegate) 瞧.cAAAAA\u003D\u003D(procAddress, 瞊.MAAAAA\u003D\u003D(__typeref (InitializeDelegate))))(obj0);
  }

  internal static void ExitThroughDelegate()
  {
    IntPtr procAddress = \u003CAgileDotNetRT\u003E.GetProcAddress(\u003CAgileDotNetRT\u003E.Load(), "_AtExit");
    // ISSUE: type reference
    ((ExitDelegate) 瞧.cAAAAA\u003D\u003D(procAddress, 瞊.MAAAAA\u003D\u003D(__typeref (ExitDelegate))))();
  }

  internal static void ExitThroughDelegate64()
  {
    IntPtr procAddress = \u003CAgileDotNetRT\u003E.GetProcAddress(\u003CAgileDotNetRT\u003E.Load(), "_AtExit64");
    // ISSUE: type reference
    ((ExitDelegate) 瞧.cAAAAA\u003D\u003D(procAddress, 瞊.MAAAAA\u003D\u003D(__typeref (ExitDelegate))))();
  }

  internal static void DomainUnload([In] object obj0, [In] EventArgs obj1)
  {
    if (瞜.bQAAAA\u003D\u003D() == 4)
      \u003CAgileDotNetRT\u003E.ExitThroughDelegate();
    else
      \u003CAgileDotNetRT\u003E.ExitThroughDelegate64();
  }

  internal static void Initialize()
  {
    if (\u003CAgileDotNetRT\u003E.inited)
      return;
    RuntimeMethodHandle runtimeMethodHandle = 瞪.dQAAAA\u003D\u003D\u0025((object) 瞩.dAAAAA\u003D\u003D\u0025((object) 瞨.cwAAAA\u003D\u003D\u0025((object) new StackTrace(), 0)));
    if ((瞜.bQAAAA\u003D\u003D() != 4 ? \u003CAgileDotNetRT\u003E.InitializeThroughDelegate64(runtimeMethodHandle.Value) : \u003CAgileDotNetRT\u003E.InitializeThroughDelegate(runtimeMethodHandle.Value)) == 1)
      瞬.SwAAAA\u003D\u003D\u0025((object) 瞫.SQAAAA\u003D\u003D(), new EventHandler(\u003CAgileDotNetRT\u003E.DomainUnload));
    \u003CAgileDotNetRT\u003E.inited = true;
  }

  internal static void PostInitialize()
  {
  }
}
