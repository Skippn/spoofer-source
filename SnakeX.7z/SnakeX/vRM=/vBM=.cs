﻿// Decompiled with JetBrains decompiler
// Type: vRM=.vBM=
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace vRM\u003D
{
  [DebuggerNonUserCode]
  [CompilerGenerated]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  internal class vBM\u003D
  {
    private static ResourceManager vhM\u003D;
    private static CultureInfo vxM\u003D;

    [MethodImpl(MethodImplOptions.NoInlining)]
    internal vBM\u003D()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager wRM\u003D
    {
      [MethodImpl(MethodImplOptions.NoInlining)] get => (ResourceManager) null;
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo xBM\u003D
    {
      [MethodImpl(MethodImplOptions.NoInlining)] get => (CultureInfo) null;
      [MethodImpl(MethodImplOptions.NoInlining)] set
      {
      }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    static vBM\u003D()
    {
      \u003CAgileDotNetRT\u003E.Initialize();
      \u003CAgileDotNetRT\u003E.PostInitialize();
    }
  }
}
