﻿// Decompiled with JetBrains decompiler
// Type: Snake_X.Properties.Settings
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Snake_X.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.6.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance;

    public static Settings Default
    {
      [MethodImpl(MethodImplOptions.NoInlining)] get => (Settings) null;
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    public Settings()
    {
    }

    static Settings()
    {
      \u003CAgileDotNetRT\u003E.Initialize();
      \u003CAgileDotNetRT\u003E.PostInitialize();
      // ISSUE: reference to a compiler-generated field
      // ISSUE: object of a compiler-generated type is created
      Settings.defaultInstance = (Settings) 瞌.\u0036QAAAA\u003D\u003D((SettingsBase) new Settings());
    }
  }
}
