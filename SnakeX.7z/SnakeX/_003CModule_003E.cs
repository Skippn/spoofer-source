﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System.Runtime.CompilerServices;
using tD4\u003D;

internal class \u003CModule\u003E
{
  [MethodImpl(MethodImplOptions.NoInlining)]
  static \u003CModule\u003E()
  {
    \u003CAgileDotNetRT\u003E.Initialize();
    \u003CAgileDotNetRT\u003E.PostInitialize();
    tj4\u003D.rrr();
  }
}
