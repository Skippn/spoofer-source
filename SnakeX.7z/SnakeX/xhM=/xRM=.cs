﻿// Decompiled with JetBrains decompiler
// Type: xhM=.xRM=
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace xhM\u003D
{
  public class xRM\u003D : Form
  {
    private string xxM\u003D;
    private IContainer oxM\u003D;
    private TextBox yBM\u003D;
    private Label sRM\u003D;
    private Button pBM\u003D;
    private Button pRM\u003D;
    private Label sxM\u003D;
    private Label tBM\u003D;
    private LinkLabel sBM\u003D;
    private Label yRM\u003D;
    private Label yhM\u003D;
    private Button shM\u003D;
    private Button qxM\u003D;
    private Label yxM\u003D;

    [MethodImpl(MethodImplOptions.NoInlining)]
    public xRM\u003D()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void zBM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void pxM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void phM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void zRM\u003D()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void zhM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void zxM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void \u0030BM\u003D(object sender, LinkLabelLinkClickedEventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void rRM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void uhM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void rBM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void \u0030RM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void \u0030hM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    protected override void Dispose(bool disposing)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void qRM\u003D()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    static xRM\u003D()
    {
      \u003CAgileDotNetRT\u003E.Initialize();
      \u003CAgileDotNetRT\u003E.PostInitialize();
    }
  }
}
