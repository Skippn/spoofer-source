﻿// Decompiled with JetBrains decompiler
// Type: xhM=.2BM=
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System;
using System.Runtime.CompilerServices;

namespace xhM\u003D
{
  internal static class \u0032BM\u003D
  {
    [STAThread]
    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void \u0032RM\u003D()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    static \u0032BM\u003D()
    {
      \u003CAgileDotNetRT\u003E.Initialize();
      \u003CAgileDotNetRT\u003E.PostInitialize();
    }
  }
}
