﻿// Decompiled with JetBrains decompiler
// Type: ohM=.rxM=
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace ohM\u003D
{
  public class rxM\u003D : Form
  {
    private IContainer oxM\u003D;
    private Button pBM\u003D;
    private Button pRM\u003D;
    private LinkLabel sBM\u003D;
    private Label sRM\u003D;
    private Button qxM\u003D;
    private Button shM\u003D;
    private Label sxM\u003D;
    private Label tBM\u003D;
    private Button tRM\u003D;
    private Button thM\u003D;

    [MethodImpl(MethodImplOptions.NoInlining)]
    public rxM\u003D()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void pxM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void phM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private string txM\u003D() => (string) null;

    [MethodImpl(MethodImplOptions.NoInlining)]
    private string uBM\u003D() => (string) null;

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void rBM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void uRM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void rRM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void uhM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void uxM\u003D(object sender, EventArgs e)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    protected override void Dispose(bool disposing)
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private void qRM\u003D()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    static rxM\u003D()
    {
      \u003CAgileDotNetRT\u003E.Initialize();
      \u003CAgileDotNetRT\u003E.PostInitialize();
    }
  }
}
