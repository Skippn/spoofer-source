﻿// Decompiled with JetBrains decompiler
// Type: tD4=.tj4=
// Assembly: SnakeX, Version=1.0.0.0, Culture=neutral
// MVID: C625DC00-1E86-461B-96E2-8DCB08A08108
// Assembly location: C:\Users\lande\OneDrive\Bureaublad\SnakeX.exe

using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using tD4\u003D;

namespace tD4\u003D
{
  internal class tj4\u003D
  {
    private static Assembly tz4\u003D;
    private static string[] uD4\u003D;

    [Obfuscation]
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static void rrr()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    public static Assembly uT4\u003D(object sender, ResolveEventArgs args) => (Assembly) null;

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static byte[] uj4\u003D(Stream resourceStream) => (byte[]) null;

    [MethodImpl(MethodImplOptions.NoInlining)]
    public tj4\u003D()
    {
    }

    static tj4\u003D()
    {
      \u003CAgileDotNetRT\u003E.Initialize();
      \u003CAgileDotNetRT\u003E.PostInitialize();
      tj4\u003D.uD4\u003D = new string[0];
    }
  }
}
